from pandas.tseries.holiday import Holiday

InternationalLaborDay = Holiday('LabourDay', month=5, day=1)
